#include "Decorator.h"

Decorator::Decorator(Farm* farm) { //
	this->farmLand = farm;
}

Decorator::Decorator() {
	
}
